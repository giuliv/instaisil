//
//  SubirFotoViewController.swift
//  Proyecto_Iphone
//
//  Created by Alumno on 11/22/19.
//  Copyright © 2019 alumno.com. All rights reserved.
//

import UIKit
import Firebase
import Foundation

class SubirFotoViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var postFotoView: UIImageView!
    
    var imagePicker:UIImagePickerController!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let imageTap = UITapGestureRecognizer(target: self, action: #selector(openImagePicker))
        postFotoView.isUserInteractionEnabled = true
        postFotoView.addGestureRecognizer(imageTap)
        postFotoView.clipsToBounds = true
        
        imagePicker = UIImagePickerController()
        imagePicker.allowsEditing = true
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
        
        
        
    }
    @objc func openImagePicker(_ sender:Any) {
        // Open Image Picker
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    
}


extension SubirFotoViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    internal func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            self.postFotoView.image = pickedImage
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    
}

