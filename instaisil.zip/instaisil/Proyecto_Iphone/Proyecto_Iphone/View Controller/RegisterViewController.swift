//
//  RegisterViewController.swift
//  Proyecto_Iphone
//
//  Created by alumno on 9/19/19.
//  Copyright © 2019 alumno.com. All rights reserved.
//

import UIKit
import FirebaseAuth

class RegisterViewController: UIViewController {


    @IBOutlet weak var Nombre: UITextField!
    @IBOutlet weak var Contraseña: UITextField!
    @IBOutlet weak var Apellido: UITextField!
    @IBOutlet weak var Correo: UITextField!
    
    @IBAction func btnRegistrar(_ sender: UIButton) {
        
        if  self.Correo.text == "" || self.Contraseña.text == ""{
        
        let alertController = UIAlertController(title: "Nuevo Usuario",
                                      message: "Introduce tus datos por favor",
                                      preferredStyle: .alert)
        //2.
        let saveAction = UIAlertAction(title: "Guardar",
                                       style: .default,
                                       handler: nil)

                                        
                     alertController.addAction(saveAction)
            
            self.present(alertController, animated: true, completion: nil)
        } else {
            //2.
            Auth.auth().createUser(withEmail: Correo.text!, password: Contraseña.text!) { (user, error) in
                //3.
                if error == nil {
                    
                } else {
                    //4.
                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
        self.navigationController?.popViewController(animated: true)
}
    
    
    @IBAction func clibkBotonRegister(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
