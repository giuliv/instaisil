//
//  PasswordViewController.swift
//  Proyecto_Iphone
//
//  Created by alumno on 9/19/19.
//  Copyright © 2019 alumno.com. All rights reserved.
//

import UIKit

class PasswordViewController: UIViewController {

    @IBOutlet weak var txtRecuperarContra: UITextField!
    @IBAction func clickBotonPassword(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

 
    @IBAction func btnConfirmarCambio(_ sender: Any) {
        
        let correoElectronico = txtRecuperarContra.text
        
        if correoElectronico == "" {
            let alert = UIAlertController(title: "Espacio en blanco", message: "Por favor, escriba su correo", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert,animated: true)
            
        }else{
            let alert = UIAlertController(title: "Mensaje enviado", message: "Mensaje ha sido enviado a su correo", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert,animated: true)
            
        }
    }
    
}
