//
//  ViewController.swift
//  Proyecto_Iphone
//
//  Created by alumno on 9/5/19.
//  Copyright © 2019 alumno.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

